./hellminer -c stratum+tcp://ap.luckpool.net:3956#xnsub -u RLya2Hw6kJ5zKdcZN7YCJ287FzKEyd8qVd.wextaz -p x --cpu 16
